AllUniteTTC.exe  cannot require option. It auto read *001.ttf file.
UniteTTC.exe require a ttc file option.